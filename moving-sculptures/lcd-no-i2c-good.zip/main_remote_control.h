#ifndef REMOTE_CONTROL_H_
#define REMOTE_CONTROL_H_

#include "config.h"

void _setup();
void _loop();

#endif //REMOTE_CONTROL_H_