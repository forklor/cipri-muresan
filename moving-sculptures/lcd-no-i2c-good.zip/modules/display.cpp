#include "display.h"

#define I2C_ADDR  0x3F
#define En_pin  11
#define Rw_pin  1
#define Rs_pin  12
#define D4_pin  5
#define D5_pin  4
#define D6_pin  3
#define D7_pin  2

//const int rs = 12, en = 11, d4 = 5, d5 = 4, d6 = 3, d7 = 2;
//LiquidCrystal lcd(rs, en, d4, d5, d6, d7);
LiquidCrystal display_lcd(Rs_pin, En_pin, D4_pin, D5_pin, D6_pin, D7_pin);

bool hasMessage;
long messageStartTime;
long messageDisplayTime;

void _display_setup() {
	display_lcd.begin(16, 2);
	display_lcd.setCursor(0, 0);
	display_lcd.print(" ");
}

void _display_loop(long milliseconds) {
	if(hasMessage && milliseconds - messageStartTime >= messageDisplayTime) {
		hasMessage = false;
	}
}

void display_show_message(char *line1, char *line2, long timeMs) {
	display_lcd.clear();
	display_lcd.setCursor(0, 0);
	display_lcd.print(line1);

	display_lcd.setCursor(0, 1);
	display_lcd.print(line2);

	messageStartTime = millis();
	messageDisplayTime = timeMs;
	hasMessage = true;
}

bool display_has_message() {
	return hasMessage;
}
