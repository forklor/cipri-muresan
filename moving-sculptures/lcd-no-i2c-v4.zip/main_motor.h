#ifndef MOTOR_MAIN_H_
#define MOTOR_MAIN_H_

#include "config.h"

void _setup();
void _loop();

#endif //MOTOR_MAIN_H_