// Use this file to configure the build target
// when REMOTE_CONTROL_CONTROLLER is defined, the build is made for remote control module
// when MOTOR_CONTROLLER is defined the build is made for one motore module
// 	 to define which motor module is the target, use MOTOD_MODULE_NUMBER. This takes values from 1 to 6

#define REMOTE_CONTROL_CONTROLLER 1

//#define MOTOR_CONTROLLER 1

//#define MOTOR_MODULE_NUMBER 6